from django.shortcuts import render
from django.http import HttpResponse
from .models import Product

def test_response(request):
    # return HttpResponse('<h1>Test response string</h1>')
    # test = ['product1', 'product2']
    all_products = Product.objects.all()
    return render(request, 'display_products.html', {'products_list': all_products})
