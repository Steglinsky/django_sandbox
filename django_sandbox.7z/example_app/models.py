from django.db import models


class Product(models.Model):
    name = models.CharField(max_length=50)
    description = models.TextField(max_length=300, default='SOME STRING')
    availability = models.BooleanField(default=False)
    amount = models.PositiveIntegerField(default=False)
    price = models.DecimalField(max_digits=10, decimal_places=2, default=False)


'''
    def get_display_name(self):
        return f'{self.name} {self.amount}'

    def __str__(self):
        return self.get_display_name()

'''

#def __str__(self):
#    return self.name
