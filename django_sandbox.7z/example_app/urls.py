from django.urls import path, include
from example_app.views import test_response

urlpatterns = [
    path('test/', test_response)


]
